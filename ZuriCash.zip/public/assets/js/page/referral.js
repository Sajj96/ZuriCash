"use strict";

$(document).ready(function (){

    new Clipboard('.btn');

});