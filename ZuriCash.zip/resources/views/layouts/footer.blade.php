<footer class="main-footer">
    <div class="footer-left">
        <a href="templateshub.net">&copy;Copyright ZURICASH AGENCY <?php echo date('Y');?></a></a>
    </div>
    <div class="footer-right">
    </div>
</footer>
</div>